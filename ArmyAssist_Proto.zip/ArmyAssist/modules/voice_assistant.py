# Voice command recognition + TTS responses
