# YOLOv8 real-time detection code
